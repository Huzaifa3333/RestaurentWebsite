const mongoose=require("mongoose");
const reservationSchema=mongoose.Schema({
    name:String,
    email:String,
    phone:String,
    date:String,
    time:String,
    guest:String
});
module.exports=mongoose.model("Reservation",reservationSchema);