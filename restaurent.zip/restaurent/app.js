const express=require('express');
const app=express();
const path = require('path');
const cookieParser = require('cookie-parser');
const mongoose = require('mongoose');
mongoose.connect("mongodb://127.0.0.1:27017/auth_demo");
const userModel=require("./models/user");
const bcrypt=require('bcrypt');
const reservationModel=require('./models/reservation');


app.set("view engine","ejs");
app.set('views', path.join(__dirname, 'views'));
app.use(express.static (path.join(__dirname, 'public')));
app.use(express.urlencoded({extended:true}));
app.use(cookieParser());

app.get("/",(req,res)=>{
    res.render("index");
})

app.post("/signup",async (req,res)=>{
    let {username,email,password,confirmpassword}=req.body;
     if (password !== confirmpassword) {
        return res.render("index", { error: "Passwords do not match" });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    let  createuser=userModel.create({
        username,
        email,
        password:hashedPassword
    });
    res.redirect('/login');
});
app.get('/login',async (req, res) => {
    res.render('login');
});

app.post("/login",async (req,res)=>{
    let {email,password}=req.body;
    const user=await userModel.findOne({email});
    if(user){
       const isMatch= await bcrypt.compare(password, user.password);
       if(isMatch) {
            res.render('dashboard', { username: user.username });
        } else {
            return res.render('login', { error: "email or password is incorrect" });
        }
    }else{
            res.render('login', { error:"email or password is incorrect" });
        }
    })

app.get("/logout", (req, res) => {
    res.redirect("/login");  
});

app.get("/reservation",(req,res)=>{
    res.send("reservation");
});



const nodemailer = require('nodemailer');
app.post('/reserve',async (req,res)=>{
    const{name,email,phone,date,time,guest}=req.body;
    const existing = await reservationModel.findOne({ date: date, time: time });

    if (existing) {
    return res.render('error', {
        message: "Table is already reserved for this date and time."
    });
}

await reservationModel.create({ name, email, phone, date, time, guests: guest });
    //EMAIL TRANSPOT SETUP
    const transporter=nodemailer.createTransport({
        service:'gmail',
        auth:{
            user:'huzaifaawaan970@gmail.com',
            pass:'iknh dgdx yhhx nqig'
        }
    });
    //EMAIL CONTENY
    const mailOptions={
        from:'huzaifaawaan970@gmail.com',
        to:'huzaifaawaan970@gmail.com',
        subject:'New Table Reservation',
        text:`
        Name: ${name}
        Email: ${email}
        Phone: ${phone}
        Date: ${date}
        Time: ${time}
        Guests: ${guest}
        `
    };
    try {
        await transporter.sendMail(mailOptions);
      res.render('success',{
            message: "Your table has been reserved successfully!"
        });
    } catch (err) {
        console.error(err);
        res.send('Failed to send email.');
    }
});



app.listen(3000);