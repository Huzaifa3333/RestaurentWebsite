function scrollToHome(){
    const homeSection=document.getElementById("home");
    homeSection.scrollIntoView({behavior:"smooth"});
     document.getElementById('mobileMenu').classList.remove('active');
}
function scrollToAbout(){
    const aboutSection=document.getElementById("about");
    aboutSection.scrollIntoView({behavior:"smooth"});
     document.getElementById('mobileMenu').classList.remove('active');
}
function scrollToChef(){
    const chefSection=document.getElementById("chef");
    chefSection.scrollIntoView({behavior:"smooth"})
     document.getElementById('mobileMenu').classList.remove('active');
}
function scrollToMenu(){
    const menuSection=document.getElementById("menu");
    menuSection.scrollIntoView({behavior:"smooth"})
     document.getElementById('mobileMenu').classList.remove('active');
}
function scrollToReservation(){
    event.preventDefault();
    const reservationSection=document.getElementById("reservation");
     document.getElementById('mobileMenu').classList.remove('active');
    reservationSection.scrollIntoView({behavior:"smooth"})
}
function scrollToContact(){
    event.preventDefault();
    const contactSection=document.getElementById("contact");
    contactSection.scrollIntoView({behavior:"smooth"})
     document.getElementById('mobileMenu').classList.remove('active');
}
window.addEventListener("load", function () {
    setTimeout(function () {
      window.scrollTo(0, 0);
    }, 0);
  });

document.querySelector('.menu-toggle').addEventListener('click', function () {
document.getElementById('mobileMenu').classList.toggle('active');

});



